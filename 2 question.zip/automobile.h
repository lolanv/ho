#pragma once
#include "automobile_type.h"
#include <string>

class Automobile {
public:
    std::string _id;
    AutomobileType _type;
    float _price;
    int _seat_count;
    int _engine_horsepower;

public:
    Automobile(std::string id, AutomobileType type, float price, int seat_count, int engine_horsepower);
    float CalculateGST();
};
