#pragma once

enum class AutomobileType {
    REGULAR,
    TRANSPORT
};
