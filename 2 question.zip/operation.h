#pragma once

#include <memory>
#include <vector>
#include <thread>

#include "automobile.h"
#include "evcar.h"

class Operation {
private:
    std::vector<std::shared_ptr<Automobile>> automobiles;
    std::vector<std::shared_ptr<EvCar>> evCars;

    Operation();

public:
    static Operation& getInstance();

    void createObjects();
    void displayAverageGST();
    void displayAbove4SeatsCount();
    void displayAveragePrice();
    void displayDCChargingType();

    Operation(const Operation&) = delete;
    Operation& operator=(const Operation&) = delete;
};
