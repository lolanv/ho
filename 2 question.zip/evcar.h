#pragma once

#include <string>

class EvCar {
public:
    float _battery_capacity;
    float _price;
    std::string _charging_type;

public:
    EvCar(float battery_capacity, float price, std::string charging_type);
    float CalculateGST();
};
