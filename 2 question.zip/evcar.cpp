#include "evcar.h"

EvCar::EvCar(float battery_capacity, float price, std::string charging_type)
    : _battery_capacity(battery_capacity), _price(price), _charging_type(charging_type) {}

float EvCar::CalculateGST() {
    return 0.10f * _price;
}
