#include "operation.h"

#include <iostream>
#include <numeric>

Operation::Operation() {}

Operation& Operation::getInstance() {
    static Operation instance;
    return instance;
}

void Operation::createObjects() {
    // Creating Automobile instances
    automobiles.push_back(std::make_shared<Automobile>("1", AutomobileType::REGULAR, 20000.0f, 5, 200));
    automobiles.push_back(std::make_shared<Automobile>("2", AutomobileType::TRANSPORT, 30000.0f, 7, 300));
    automobiles.push_back(std::make_shared<Automobile>("3", AutomobileType::REGULAR, 25000.0f, 4, 180));

    // Creating EvCar instances
    evCars.push_back(std::make_shared<EvCar>(100.0f, 40000.0f, "DC"));
    evCars.push_back(std::make_shared<EvCar>(120.0f, 50000.0f, "AC"));
}

void Operation::displayAverageGST() {
    float totalGST = 0.0f;
    for (const auto& evCar : evCars) {
        totalGST += evCar->CalculateGST();
    }
    float averageGST = totalGST / evCars.size();
    std::cout << "Average GST for EvCars: " << averageGST << std::endl;
}

void Operation::displayAbove4SeatsCount() {
    int count = 0;
    for (const auto& autoMobile : automobiles) {
        if (autoMobile->_seat_count > 4) {
            count++;
        }
    }
    std::cout << "Count of Automobiles with seat count above 4: " << count << std::endl;
}

void Operation::displayAveragePrice() {
    float totalPrice = 0.0f;
    for (const auto& autoMobile : automobiles) {
        totalPrice += autoMobile->_price;
    }
    float averagePrice = totalPrice / automobiles.size();
    std::cout << "Average price of all Automobiles: " << averagePrice << std::endl;
}

void Operation::displayDCChargingType() {
    bool foundDC = false;
    for (const auto& evCar : evCars) {
        if (evCar->_charging_type == "DC") {
            foundDC = true;
            break;
        }
    }
    std::cout << "EvCar with DC charging type found: " << std::boolalpha << foundDC << std::endl;
}
    