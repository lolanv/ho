#include "operation.h"
#include <thread>

int main() {
    Operation& operation = Operation::getInstance();

    std::thread createThread(&Operation::createObjects, &operation);
    std::thread averageGSTThread(&Operation::displayAverageGST, &operation);
    std::thread above4SeatsCountThread(&Operation::displayAbove4SeatsCount, &operation);
    std::thread averagePriceThread(&Operation::displayAveragePrice, &operation);
    std::thread dcChargingTypeThread(&Operation::displayDCChargingType, &operation);

    createThread.join();
    averageGSTThread.join();
    above4SeatsCountThread.join();
    averagePriceThread.join();
    dcChargingTypeThread.join();

    return 0;
}
