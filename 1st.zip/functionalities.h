#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include"Exception.h"
#include <vector>
#include <string>
#include <functional>
#include <future>
#include <optional>

std::optional<int> sumFirstThree(const std::vector<int>& container);
std::optional<int> minLastThree(const std::vector<int>& container);
std::vector<int> primeNumbers(const std::vector<int>& container);
std::vector<int> filterByPredicate(const std::vector<int>& container, std::function<bool(int)> predicate);
std::optional<std::string> maxStringLength(const std::vector<std::string>& container);
std::vector<char> removeVowels(const std::vector<std::string>& container);

#endif // FUNCTIONALITIES_H
