#include "functionalities.h"
#include <vector>
#include <string>
#include <functional>
#include <stdexcept>

bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) return false;
    }
    return true;
}

std::optional<int> sumFirstThree(const std::vector<int>& container) {
    if(container.empty()) {
        throw Exception("data empty", std::future_errc::no_state);
    }
    if (container.size() < 3) return std::nullopt;
    int sum = 0;
    for (size_t i = 0; i < 3; ++i) {
        sum += container[i];
    }
    return sum;
}

std::optional<int> minLastThree(const std::vector<int>& container) {
    if(container.empty()) {
        throw Exception("data empty", std::future_errc::no_state);
    }
    if (container.size() < 3) return std::nullopt;
    int min = container[container.size() - 3];
    for (size_t i = container.size() - 2; i < container.size(); ++i) {
        if (container[i] < min) min = container[i];
    }
    return min;
}

std::vector<int> primeNumbers(const std::vector<int>& container) {
    if(container.empty()) {
        throw Exception("data empty", std::future_errc::no_state);
    }
    std::vector<int> primes;
    for (int num : container) {
        if (isPrime(num)) primes.push_back(num);
    }
    return primes;
}

std::vector<int> filterByPredicate(const std::vector<int>& container, std::function<bool(int)> predicate) {
    if(container.empty()) {
        throw Exception("data empty", std::future_errc::no_state);
    }
    std::vector<int> filtered;
    for (int num : container) {
        if (predicate(num)) filtered.push_back(num);
    }
    return filtered;
}

std::optional<std::string> maxStringLength(const std::vector<std::string>& container) {
    if (container.empty()) return std::nullopt;
    std::string maxStr = container.front();
    for (const std::string& str : container) {
        if (str.size() > maxStr.size()) maxStr = str;
    }
    return maxStr;
}

std::vector<char> removeVowels(const std::vector<std::string>& container) {
    if(container.empty()) {
        throw Exception("data empty", std::future_errc::no_state);
    }
    std::vector<char> nonVowels;
    for (const std::string& str : container) {
        for (char c : str) {
            char lowerC = tolower(c);
            if (lowerC != 'a' && lowerC != 'e' && lowerC != 'i' && lowerC != 'o' && lowerC != 'u') {
                nonVowels.push_back(c);
            }
        }
    }
    return nonVowels;
}
