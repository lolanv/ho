#include <iostream>
#include <vector>
#include <string>
#include <functional>
#include <future>
#include <stdexcept>
#include "functionalities.h"

int main() {
    try {
        std::vector<int> intContainer = {1, 2, 3, 4, 5};
        std::vector<std::string> strContainer = {"C++", "Coding", "Demo"};

        auto sumFuture = std::async(std::launch::async, sumFirstThree, intContainer);
        auto minFuture = std::async(std::launch::async, minLastThree, intContainer);
        auto primesFuture = std::async(std::launch::async, primeNumbers, intContainer);
        auto filteredFuture = std::async(std::launch::async, filterByPredicate, intContainer, [](int num) { return num % 2 == 0; });
        auto maxStrFuture = std::async(std::launch::async, maxStringLength, strContainer);
        auto nonVowelsFuture = std::async(std::launch::async, removeVowels, strContainer);

        // Wait for futures to complete and handle results
        std::cout << "Sum of first three numbers: " << sumFuture.get().value_or(0) << std::endl;
        std::cout << "Minimum of last three numbers: " << minFuture.get().value_or(0) << std::endl;
        auto primes = primesFuture.get();
        std::cout << "Prime numbers: ";
        for (int prime : primes) {
            std::cout << prime << " ";
        }
        std::cout << std::endl;
        auto filtered = filteredFuture.get();
        std::cout << "Filtered by predicate: ";
        for (int num : filtered) {
            std::cout << num << " ";
        }
        std::cout << std::endl;
        std::cout << "String with maximum length: " << maxStrFuture.get().value_or("No strings") << std::endl;
        auto nonVowels = nonVowelsFuture.get();
        std::cout << "Non-vowel characters: ";
        for (char c : nonVowels) {
            std::cout << c << " ";
        }
        std::cout << std::endl;
    } catch (const std::future_error& e) {
        std::cerr << "Future error occurred: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
